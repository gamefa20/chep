#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=https://server1.whalestonpool.com
WALLET=EQAlaSdOMw8otd8pkzMkE2Cb6D7dtdG22tWk_9uzYWoJSz56

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./game_chap --algo TON --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./game_chap --algo TON --pool $POOL --user $WALLET $@
done
